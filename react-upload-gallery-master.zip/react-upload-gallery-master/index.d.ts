declare module "react-upload-gallery";
declare var RUG: any;
